import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const articles = pgTable("articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  topic: text("topic").notNull(),
  language: text("language").notNull().default("english"),
  wordCount: integer("word_count").notNull(),
  tone: text("tone").notNull().default("professional"),
  metaDescription: text("meta_description"),
  keywords: json("keywords").$type<string[]>().default([]),
  images: json("images").$type<{ url: string; alt: string; prompt: string }[]>().default([]),
  seoScore: integer("seo_score").default(0),
  readabilityScore: text("readability_score").default("Good"),
  status: text("status").notNull().default("draft"), // draft, published
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const generateArticleSchema = z.object({
  topic: z.string().min(1, "Topic is required"),
  language: z.string().default("english"),
  wordCount: z.number().min(500).max(3000),
  tone: z.enum(["professional", "casual", "storytelling", "marketing"]),
  imageCount: z.number().min(0).max(5).default(3),
  imageStyle: z.enum(["realistic", "digital-art", "cartoon", "anime"]).default("realistic"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type Article = typeof articles.$inferSelect;
export type GenerateArticleRequest = z.infer<typeof generateArticleSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
