# Overview

This project is an AI-powered blog generator application that creates SEO-optimized articles and blog posts using Google's Gemini API. The application is built as a full-stack web application with a React frontend and Express.js backend, designed to help users generate high-quality, SEO-friendly content with integrated images and comprehensive optimization features.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom CSS variables for theming (supports dark/light modes)
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas

## Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Express sessions with PostgreSQL store (connect-pg-simple)
- **API Structure**: RESTful endpoints with centralized error handling

## Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon Database serverless
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema Management**: Drizzle Kit for migrations and schema management
- **In-Memory Storage**: Fallback memory storage implementation for development
- **Data Models**: Articles and Users tables with JSON fields for complex data types

## Authentication and Authorization
- **Session-based Authentication**: Express sessions stored in PostgreSQL
- **Password Security**: Planned implementation (schema includes password fields)
- **User Management**: Basic user creation and retrieval system

## External Service Integrations
- **AI Text Generation**: Google Gemini 2.5 Flash API for article content creation
- **AI Image Generation**: Google Gemini Image API for article illustrations
- **Content Filtering**: NSFW content detection and filtering
- **SEO Analysis**: Built-in SEO scoring and optimization recommendations
- **File Generation**: PDF, DOCX, and HTML export capabilities

## Key Features Architecture
- **Multi-language Support**: Content generation in 20+ languages including Hindi, English, and Hinglish
- **Content Customization**: Variable word count (500-3000), tone selection, and style options
- **Image Integration**: AI-generated images with customizable styles and automatic ALT text
- **SEO Optimization**: Automatic keyword density analysis, meta description generation, and internal linking
- **Content Management**: Article storage, retrieval, and status management (draft/published)
- **Export Functionality**: Multiple format downloads with server-side generation

## Performance and Scalability Considerations
- **Build Optimization**: Vite for fast development and optimized production builds
- **Code Splitting**: Automatic route-based code splitting
- **Database Connection**: Connection pooling through Neon Database serverless architecture
- **Caching Strategy**: TanStack Query for client-side caching with configurable stale times
- **Error Handling**: Comprehensive error boundaries and API error handling