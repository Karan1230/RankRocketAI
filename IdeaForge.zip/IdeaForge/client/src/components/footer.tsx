import { Link } from "wouter";
import { FileText, Twitter, Linkedin, Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center">
                <FileText className="text-white text-lg" size={16} />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                AI Blog Generator
              </span>
            </div>
            <p className="text-slate-600 dark:text-slate-400 mb-4 max-w-md">
              Create high-quality, SEO-optimized blog posts and articles using advanced AI technology. 
              Perfect for content creators, marketers, and businesses.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                data-testid="social-twitter"
              >
                <Twitter size={20} />
              </a>
              <a
                href="#"
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                data-testid="social-linkedin"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="#"
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                data-testid="social-github"
              >
                <Github size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4">Product</h3>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400">
              <li>
                <Link href="/about">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Features
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Pricing
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    API
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Integrations
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4">Support</h3>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400">
              <li>
                <Link href="/contact">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Help Center
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Contact Us
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/privacy">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Privacy Policy
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/terms">
                  <span className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer">
                    Terms of Service
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-200 dark:border-slate-700 pt-8 mt-8">
          <p className="text-center text-slate-500 dark:text-slate-400 text-sm">
            © 2024 AI Blog Generator. All rights reserved. Built with AI technology for content creators.
          </p>
        </div>
      </div>
    </footer>
  );
}
