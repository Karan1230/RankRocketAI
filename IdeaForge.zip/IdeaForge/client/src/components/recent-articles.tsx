import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Link } from "wouter";
import { FileText, History, MoreVertical } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Article } from "@shared/schema";

export function RecentArticles() {
  const { data: articles, isLoading } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
  });

  if (isLoading) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <History className="text-slate-500 mr-2" size={18} />
            Recent Articles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div>
                    <Skeleton className="h-4 w-48 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
                <Skeleton className="h-6 w-16" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const recentArticles = articles?.slice(0, 5) || [];

  if (recentArticles.length === 0) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <History className="text-slate-500 mr-2" size={18} />
            Recent Articles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <FileText className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">
              No Articles Yet
            </h3>
            <p className="text-slate-500 dark:text-slate-400">
              Generate your first article to see it appear here.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getGradientClass = (index: number) => {
    const gradients = [
      "from-blue-500 to-purple-500",
      "from-green-500 to-teal-500",
      "from-purple-500 to-pink-500",
      "from-orange-500 to-red-500",
      "from-indigo-500 to-blue-500",
    ];
    return gradients[index % gradients.length];
  };

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <History className="text-slate-500 mr-2" size={18} />
          Recent Articles
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentArticles.map((article, index) => (
            <div
              key={article.id}
              className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer"
              data-testid={`recent-article-${index}`}
            >
              <Link href={`/articles/${article.id}`}>
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 bg-gradient-to-r ${getGradientClass(index)} rounded-lg flex items-center justify-center`}>
                    <FileText className="text-white" size={20} />
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                      {article.title.length > 50 
                        ? `${article.title.substring(0, 50)}...` 
                        : article.title
                      }
                    </h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      {article.wordCount.toLocaleString()} words • Generated{" "}
                      {format(new Date(article.createdAt || ''), "MMM d, yyyy")}
                    </p>
                  </div>
                </div>
              </Link>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={article.status === "published" ? "default" : "secondary"}
                  className={
                    article.status === "published"
                      ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                      : "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                  }
                  data-testid={`status-${article.status}`}
                >
                  {article.status === "published" ? "Published" : "Draft"}
                </Badge>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  data-testid={`article-menu-${index}`}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {articles && articles.length > 5 && (
          <div className="mt-4 text-center">
            <Link href="/articles">
              <Button variant="ghost" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 font-medium text-sm">
                View All Articles →
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
