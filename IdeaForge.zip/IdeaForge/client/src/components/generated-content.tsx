import { useState } from "react";
import { format } from "date-fns";
import { Download, Share, Copy, Save, Calendar, Clock, User, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Article } from "@shared/schema";

interface GeneratedContentProps {
  article: Article | null;
}

export function GeneratedContent({ article }: GeneratedContentProps) {
  const { toast } = useToast();
  const [isPublished, setIsPublished] = useState(false);

  const handleDownload = async (format: "pdf" | "docx" | "html") => {
    if (!article) return;

    try {
      const response = await fetch(`/api/articles/${article.id}/download/${format}`);
      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = `${article.title}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Download Started",
        description: `Your article is being downloaded as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "There was an error downloading your article.",
        variant: "destructive",
      });
    }
  };

  const handleCopy = async () => {
    if (!article) return;

    try {
      await navigator.clipboard.writeText(article.content);
      toast({
        title: "Copied to Clipboard",
        description: "Article content has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy content to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (!article) return;

    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.metaDescription || "",
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled the share
      }
    } else {
      // Fallback to copying URL
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Article link has been copied to your clipboard.",
      });
    }
  };

  if (!article) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-96">
          <div className="text-center">
            <Eye className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">
              No Article Generated
            </h3>
            <p className="text-slate-500 dark:text-slate-400">
              Use the form on the left to generate your first AI-powered article.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      {/* Article Header */}
      <CardHeader className="border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
              Generated Article
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleDownload("pdf")}
              data-testid="button-download-pdf"
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleShare}
              data-testid="button-share"
            >
              <Share className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCopy}
              data-testid="button-copy"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* SEO Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Word Count
            </div>
            <div
              className="text-lg font-semibold text-slate-900 dark:text-slate-100"
              data-testid="metric-word-count"
            >
              {article.wordCount.toLocaleString()}
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Readability
            </div>
            <div
              className="text-lg font-semibold text-green-600"
              data-testid="metric-readability"
            >
              {article.readabilityScore}
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              SEO Score
            </div>
            <div
              className="text-lg font-semibold text-green-600"
              data-testid="metric-seo-score"
            >
              {article.seoScore}/100
            </div>
          </div>
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Keywords
            </div>
            <div
              className="text-lg font-semibold text-slate-900 dark:text-slate-100"
              data-testid="metric-keywords"
            >
              {article.keywords?.length || 0}
            </div>
          </div>
        </div>
      </CardHeader>

      {/* Generated Article Content */}
      <CardContent className="p-6 max-h-96 overflow-y-auto">
        <article className="prose prose-slate dark:prose-invert max-w-none">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4" data-testid="article-title">
            {article.title}
          </h1>

          <div className="text-sm text-slate-600 dark:text-slate-400 mb-6 flex items-center space-x-4">
            <span className="flex items-center">
              <Calendar className="mr-1" size={14} />
              {format(new Date(article.createdAt || ''), "MMMM d, yyyy")}
            </span>
            <span className="flex items-center">
              <Clock className="mr-1" size={14} />
              {Math.ceil(article.wordCount / 200)} min read
            </span>
            <span className="flex items-center">
              <User className="mr-1" size={14} />
              AI Generated
            </span>
          </div>

          {/* Display generated images */}
          {article.images && article.images.length > 0 && (
            <div className="mb-6">
              <img
                src={article.images[0].url}
                alt={article.images[0].alt}
                className="w-full h-64 object-cover rounded-lg shadow-lg"
                data-testid="article-hero-image"
              />
            </div>
          )}

          <div
            className="article-content"
            dangerouslySetInnerHTML={{ __html: article.content }}
            data-testid="article-content"
          />

          {/* Additional images */}
          {article.images && article.images.length > 1 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
              {article.images.slice(1).map((image, index) => (
                <img
                  key={index}
                  src={image.url}
                  alt={image.alt}
                  className="w-full h-48 object-cover rounded-lg shadow-lg"
                  data-testid={`article-image-${index + 1}`}
                />
              ))}
            </div>
          )}

          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 my-6">
            <div className="flex items-start">
              <div className="text-blue-500 mr-2 mt-1">💡</div>
              <div>
                <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-1">
                  SEO Optimized Content
                </h4>
                <p className="text-blue-800 dark:text-blue-200 text-sm">
                  This article has been generated and optimized for search engines with proper keyword density, 
                  meta descriptions, and structured headings to help improve your search rankings.
                </p>
              </div>
            </div>
          </div>

          <p className="text-slate-600 dark:text-slate-400 text-sm italic mt-8">
            This article was generated using AI technology and optimized for search engines. 
            The content is designed to be informative, engaging, and SEO-friendly.
          </p>
        </article>
      </CardContent>

      {/* Article Actions */}
      <div className="p-6 border-t border-slate-200 dark:border-slate-700">
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={() => handleDownload("pdf")}
            className="flex items-center bg-blue-500 hover:bg-blue-600"
            data-testid="action-download-pdf"
          >
            <Download className="mr-2" size={16} />
            Download PDF
          </Button>
          <Button
            onClick={() => handleDownload("docx")}
            className="flex items-center bg-green-500 hover:bg-green-600"
            data-testid="action-download-docx"
          >
            <Download className="mr-2" size={16} />
            Download DOCX
          </Button>
          <Button
            onClick={() => handleDownload("html")}
            className="flex items-center bg-orange-500 hover:bg-orange-600"
            data-testid="action-download-html"
          >
            <Download className="mr-2" size={16} />
            Download HTML
          </Button>
          <Button
            variant="secondary"
            className="flex items-center"
            data-testid="action-save"
          >
            <Save className="mr-2" size={16} />
            Save to Library
          </Button>
        </div>
      </div>
    </Card>
  );
}
