import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { format } from "date-fns";
import { ArrowLeft, Download, Share2, Calendar, Clock, User, Tag } from "lucide-react";
import { Link } from "wouter";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Article } from "@shared/schema";

export default function ArticlePage() {
  const [, params] = useRoute("/articles/:id");
  const { toast } = useToast();
  const articleId = params?.id;

  const { data: article, isLoading, error } = useQuery<Article>({
    queryKey: ["/api/articles", articleId],
    queryFn: async () => {
      if (!articleId) throw new Error("No article ID provided");
      const response = await fetch(`/api/articles/${articleId}`);
      if (!response.ok) throw new Error("Article not found");
      return response.json();
    },
    enabled: !!articleId,
  });

  const handleDownload = async (format: "pdf" | "docx" | "html") => {
    if (!article) return;

    try {
      const response = await fetch(`/api/articles/${article.id}/download/${format}`);
      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = `${article.title}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Download Started",
        description: `Your article is being downloaded as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "There was an error downloading your article.",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (!article) return;

    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.metaDescription || "",
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled the share
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Article link has been copied to your clipboard.",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
        <Header />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-4 w-1/2" />
            <div className="space-y-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
        <Header />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Article Not Found
            </h1>
            <p className="text-slate-600 dark:text-slate-400 mb-8">
              The article you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/articles">
              <Button>Back to Articles</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-8">
          <Link href="/articles">
            <Button variant="ghost" className="flex items-center">
              <ArrowLeft className="mr-2" size={16} />
              Back to Articles
            </Button>
          </Link>
        </div>

        {/* Article Header */}
        <article className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden">
          <div className="p-8">
            <div className="flex items-center justify-between mb-6">
              <Badge
                variant={article.status === "published" ? "default" : "secondary"}
                className={
                  article.status === "published"
                    ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                    : "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                }
              >
                {article.status === "published" ? "Published" : "Draft"}
              </Badge>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDownload("pdf")}
                  data-testid="download-pdf"
                >
                  <Download className="mr-2" size={16} />
                  PDF
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleShare}
                  data-testid="share-article"
                >
                  <Share2 className="mr-2" size={16} />
                  Share
                </Button>
              </div>
            </div>

            <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-6" data-testid="article-title">
              {article.title}
            </h1>

            {/* Article Meta */}
            <div className="flex flex-wrap items-center gap-6 text-sm text-slate-600 dark:text-slate-400 mb-8 pb-8 border-b border-slate-200 dark:border-slate-700">
              <span className="flex items-center">
                <Calendar className="mr-2" size={16} />
                {format(new Date(article.createdAt || ''), "MMMM d, yyyy")}
              </span>
              <span className="flex items-center">
                <Clock className="mr-2" size={16} />
                {Math.ceil(article.wordCount / 200)} min read
              </span>
              <span className="flex items-center">
                <User className="mr-2" size={16} />
                AI Generated
              </span>
              <span className="flex items-center">
                <Tag className="mr-2" size={16} />
                {article.language?.charAt(0).toUpperCase() + article.language?.slice(1)}
              </span>
            </div>

            {/* Hero Image */}
            {article.images && article.images.length > 0 && (
              <div className="mb-8">
                <img
                  src={article.images[0].url}
                  alt={article.images[0].alt}
                  className="w-full h-96 object-cover rounded-lg shadow-lg"
                  data-testid="hero-image"
                />
              </div>
            )}

            {/* Article Content */}
            <div
              className="prose prose-slate dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: article.content }}
              data-testid="article-content"
            />

            {/* Additional Images */}
            {article.images && article.images.length > 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
                {article.images.slice(1).map((image, index) => (
                  <img
                    key={index}
                    src={image.url}
                    alt={image.alt}
                    className="w-full h-64 object-cover rounded-lg shadow-lg"
                    data-testid={`additional-image-${index}`}
                  />
                ))}
              </div>
            )}

            {/* Keywords */}
            {article.keywords && article.keywords.length > 0 && (
              <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-700">
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
                  Keywords
                </h3>
                <div className="flex flex-wrap gap-2">
                  {article.keywords.map((keyword, index) => (
                    <Badge key={index} variant="outline">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>

        {/* SEO Information */}
        <Card className="mt-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              SEO Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">
                  SEO Score
                </div>
                <div className="text-2xl font-bold text-green-600">
                  {article.seoScore}/100
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Word Count
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {article.wordCount.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Readability
                </div>
                <div className="text-2xl font-bold text-blue-600">
                  {article.readabilityScore}
                </div>
              </div>
            </div>
            
            {article.metaDescription && (
              <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
                <div className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">
                  Meta Description
                </div>
                <p className="text-slate-600 dark:text-slate-400">
                  {article.metaDescription}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Download Actions */}
        <Card className="mt-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              Download Options
            </h3>
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => handleDownload("pdf")}
                className="bg-red-500 hover:bg-red-600"
                data-testid="download-pdf-button"
              >
                <Download className="mr-2" size={16} />
                Download PDF
              </Button>
              <Button
                onClick={() => handleDownload("docx")}
                className="bg-blue-500 hover:bg-blue-600"
                data-testid="download-docx-button"
              >
                <Download className="mr-2" size={16} />
                Download DOCX
              </Button>
              <Button
                onClick={() => handleDownload("html")}
                className="bg-green-500 hover:bg-green-600"
                data-testid="download-html-button"
              >
                <Download className="mr-2" size={16} />
                Download HTML
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}