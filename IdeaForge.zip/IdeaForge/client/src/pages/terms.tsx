import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Terms() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-4">
            Terms & Conditions
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Last updated: December 20, 2024
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Acceptance of Terms</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                By accessing and using AI Blog Generator ("the Service"), you accept and agree 
                to be bound by the terms and provision of this agreement. If you do not agree 
                to these terms, please do not use our service.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Description of Service</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                AI Blog Generator is an artificial intelligence-powered platform that helps users 
                create SEO-optimized blog posts and articles. Our service includes:
              </p>
              <ul>
                <li>AI-powered article generation using Google Gemini API</li>
                <li>Multi-language content creation</li>
                <li>SEO optimization and analysis tools</li>
                <li>Image generation and integration</li>
                <li>Content download and export features</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>User Responsibilities</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>As a user of our service, you agree to:</p>
              <ul>
                <li>Provide accurate and truthful information</li>
                <li>Use the service only for lawful purposes</li>
                <li>Not generate content that violates any laws or regulations</li>
                <li>Not attempt to circumvent any security measures</li>
                <li>Respect intellectual property rights</li>
                <li>Comply with all applicable local, state, and federal laws</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Content Ownership and Rights</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                Content ownership and usage rights are governed as follows:
              </p>
              <ul>
                <li>You retain full ownership of content generated through our service</li>
                <li>You are responsible for ensuring generated content complies with copyright laws</li>
                <li>We do not claim ownership of your generated articles or data</li>
                <li>You grant us the right to use anonymized data to improve our service</li>
                <li>Generated content should not infringe on third-party intellectual property</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Prohibited Uses</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>You may not use our service to:</p>
              <ul>
                <li>Generate content that is illegal, harmful, or violates any laws</li>
                <li>Create misleading, false, or deceptive content</li>
                <li>Generate spam, promotional material, or unsolicited communications</li>
                <li>Produce content that infringes on intellectual property rights</li>
                <li>Create content that violates Google AdSense policies</li>
                <li>Attempt to reverse engineer or copy our AI models</li>
                <li>Use the service to compete directly with our platform</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Service Availability</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                We strive to provide reliable service, but cannot guarantee 100% uptime. 
                Service availability may be affected by:
              </p>
              <ul>
                <li>Scheduled maintenance and updates</li>
                <li>Third-party API limitations (Google Gemini)</li>
                <li>Technical difficulties or system failures</li>
                <li>Force majeure events beyond our control</li>
              </ul>
              <p>
                We will make reasonable efforts to notify users of planned maintenance 
                and minimize service disruptions.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Content Quality and Accuracy</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                While we strive to generate high-quality content:
              </p>
              <ul>
                <li>AI-generated content may contain inaccuracies or errors</li>
                <li>Users are responsible for fact-checking and verifying information</li>
                <li>We recommend reviewing and editing generated content before publication</li>
                <li>SEO scores and metrics are estimates, not guarantees</li>
                <li>Content quality may vary based on topic complexity and specificity</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Privacy and Data Protection</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                Your privacy is important to us. Please review our Privacy Policy, 
                which also governs your use of the service, to understand our practices. 
                Key points include:
              </p>
              <ul>
                <li>We collect only necessary information to provide our service</li>
                <li>Your data is protected with industry-standard security measures</li>
                <li>We do not sell or share your personal information with third parties</li>
                <li>You have rights regarding your personal data</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Limitation of Liability</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                To the maximum extent permitted by law, AI Blog Generator shall not be liable for:
              </p>
              <ul>
                <li>Any indirect, incidental, special, or consequential damages</li>
                <li>Loss of profits, data, or business opportunities</li>
                <li>Damages resulting from use or inability to use the service</li>
                <li>Content accuracy, quality, or performance issues</li>
                <li>Third-party actions or service interruptions</li>
              </ul>
              <p>
                Our total liability shall not exceed the amount paid by you for the service 
                in the twelve months preceding the claim.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Indemnification</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                You agree to indemnify and hold harmless AI Blog Generator from any claims, 
                damages, or expenses arising from:
              </p>
              <ul>
                <li>Your use of the service in violation of these terms</li>
                <li>Content you generate or publish using our service</li>
                <li>Your violation of any third-party rights</li>
                <li>Your breach of any laws or regulations</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Termination</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                Either party may terminate this agreement:
              </p>
              <ul>
                <li>We may suspend or terminate your access for terms violations</li>
                <li>You may stop using the service at any time</li>
                <li>Termination does not affect previously generated content ownership</li>
                <li>Some provisions of these terms may survive termination</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                We reserve the right to update these Terms & Conditions at any time. 
                Changes will be effective upon posting to this page. Continued use of 
                the service after changes constitutes acceptance of the updated terms.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate dark:prose-invert max-w-none">
              <p>
                If you have questions about these Terms & Conditions, please contact us:
              </p>
              <p>
                Email: legal@aibloggenerator.com<br />
                Address: 123 AI Street, Tech City, TC 12345, United States
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
