import { useState } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { ArticleGenerator } from "@/components/article-generator";
import { GeneratedContent } from "@/components/generated-content";
import { RecentArticles } from "@/components/recent-articles";
import type { Article } from "@shared/schema";

export default function Home() {
  const [generatedArticle, setGeneratedArticle] = useState<Article | null>(null);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Form Controls */}
          <div className="lg:col-span-1">
            <ArticleGenerator onArticleGenerated={setGeneratedArticle} />
          </div>

          {/* Right Column - Generated Content */}
          <div className="lg:col-span-2">
            <GeneratedContent article={generatedArticle} />
            
            {/* Recent Articles Section */}
            <RecentArticles />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
