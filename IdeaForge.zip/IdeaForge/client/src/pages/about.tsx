import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Target, Users, Shield } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-4">
            About AI Blog Generator
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            Empowering content creators with advanced AI technology to generate high-quality, 
            SEO-optimized articles in multiple languages and styles.
          </p>
        </div>

        {/* Mission Section */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-slate-900 dark:text-slate-100 mb-4">
              Our Mission
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed">
              We believe that everyone should have access to powerful content creation tools. 
              Our AI Blog Generator democratizes content creation by providing cutting-edge 
              artificial intelligence that helps writers, marketers, and businesses create 
              compelling, SEO-optimized content that ranks well and engages audiences.
            </p>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Sparkles className="h-8 w-8 text-blue-500 mr-3" />
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  AI-Powered Generation
                </h3>
              </div>
              <p className="text-slate-600 dark:text-slate-400">
                Utilizing Google's Gemini 2.5 Flash API, our platform generates human-like, 
                engaging content that's indistinguishable from professional writing.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Target className="h-8 w-8 text-green-500 mr-3" />
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  SEO Optimization
                </h3>
              </div>
              <p className="text-slate-600 dark:text-slate-400">
                Every article is automatically optimized for search engines with proper 
                keyword density, meta descriptions, and structured headings.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-purple-500 mr-3" />
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  Multi-Language Support
                </h3>
              </div>
              <p className="text-slate-600 dark:text-slate-400">
                Create content in multiple languages including English, Hindi, Spanish, 
                French, German, and more to reach global audiences.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Shield className="h-8 w-8 text-orange-500 mr-3" />
                <h3 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                  Content Safety
                </h3>
              </div>
              <p className="text-slate-600 dark:text-slate-400">
                Built-in NSFW filters and AdSense policy compliance ensure your content 
                is safe, appropriate, and monetization-ready.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Technology Section */}
        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-slate-900 dark:text-slate-100 mb-4">
              Technology Stack
            </h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              Our platform is built using cutting-edge technology to ensure reliability, 
              speed, and scalability:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  AI Models
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Google Gemini 2.5 Flash for text generation and image creation
                </p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  Frontend
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  React with TypeScript, TailwindCSS, and Shadcn UI components
                </p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  Backend
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Node.js with Express, ensuring fast and reliable API responses
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Team Section */}
        <Card>
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-semibold text-slate-900 dark:text-slate-100 mb-4">
              Built for Content Creators
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-lg max-w-2xl mx-auto">
              Whether you're a blogger, marketer, business owner, or content agency, 
              our AI Blog Generator is designed to streamline your content creation 
              process while maintaining the highest quality standards.
            </p>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}
