import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateArticleSchema, type GenerateArticleRequest } from "@shared/schema";
import { generateArticleContent, generateArticleImages, filterNSFWContent } from "./services/gemini";
import { analyzeSEO, generateInternalLinks } from "./services/seo";
import { generatePDF, generateDOCX, generateHTML } from "./services/download";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Generate article endpoint
  app.post("/api/articles/generate", async (req, res) => {
    try {
      const validatedData = generateArticleSchema.parse(req.body);
      
      // Generate article content using Gemini
      const generatedArticle = await generateArticleContent(validatedData);
      
      // Filter NSFW content
      const contentFilter = await filterNSFWContent(generatedArticle.content);
      if (!contentFilter.isClean) {
        return res.status(400).json({ 
          message: "Generated content contains inappropriate material",
          issues: contentFilter 
        });
      }
      
      // Generate images if requested
      let images: Array<{url: string; alt: string; prompt: string}> = [];
      if (validatedData.imageCount > 0) {
        try {
          images = await generateArticleImages(
            validatedData.topic,
            validatedData.imageCount,
            validatedData.imageStyle
          );
        } catch (error) {
          console.error("Image generation failed:", error);
          // Continue without images if generation fails
        }
      }
      
      // Get existing articles for internal linking
      const existingArticles = await storage.getAllArticles();
      const contentWithLinks = generateInternalLinks(
        contentFilter.cleanedContent || generatedArticle.content,
        existingArticles.map(a => ({ title: a.title, id: a.id }))
      );
      
      // Perform SEO analysis
      const seoAnalysis = analyzeSEO(contentWithLinks, generatedArticle.title, generatedArticle.keywords);
      
      // Save article to storage
      const article = await storage.createArticle({
        title: generatedArticle.title,
        content: contentWithLinks,
        topic: validatedData.topic,
        language: validatedData.language,
        wordCount: seoAnalysis.wordCount,
        tone: validatedData.tone,
        metaDescription: seoAnalysis.metaDescription,
        keywords: generatedArticle.keywords,
        images,
        seoScore: seoAnalysis.score,
        readabilityScore: seoAnalysis.readabilityScore,
        status: "draft"
      });
      
      res.json(article);
    } catch (error) {
      console.error("Error generating article:", error);
      res.status(500).json({ message: "Failed to generate article", error: error instanceof Error ? error.message : String(error) });
    }
  });
  
  // Get all articles
  app.get("/api/articles", async (req, res) => {
    try {
      const articles = await storage.getAllArticles();
      res.json(articles);
    } catch (error) {
      console.error("Error fetching articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });
  
  // Get single article
  app.get("/api/articles/:id", async (req, res) => {
    try {
      const article = await storage.getArticle(req.params.id);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      console.error("Error fetching article:", error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });
  
  // Update article
  app.put("/api/articles/:id", async (req, res) => {
    try {
      const updates = req.body;
      const article = await storage.updateArticle(req.params.id, updates);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      console.error("Error updating article:", error);
      res.status(500).json({ message: "Failed to update article" });
    }
  });
  
  // Delete article
  app.delete("/api/articles/:id", async (req, res) => {
    try {
      const success = await storage.deleteArticle(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json({ message: "Article deleted successfully" });
    } catch (error) {
      console.error("Error deleting article:", error);
      res.status(500).json({ message: "Failed to delete article" });
    }
  });
  
  // Download article in different formats
  app.get("/api/articles/:id/download/:format", async (req, res) => {
    try {
      const { id, format } = req.params;
      const article = await storage.getArticle(id);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      switch (format) {
        case "pdf":
          const pdfBuffer = generatePDF(article);
          res.setHeader('Content-Type', 'application/pdf');
          res.setHeader('Content-Disposition', `attachment; filename="${article.title}.pdf"`);
          res.send(pdfBuffer);
          break;
          
        case "docx":
          const docxBuffer = generateDOCX(article);
          res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
          res.setHeader('Content-Disposition', `attachment; filename="${article.title}.docx"`);
          res.send(docxBuffer);
          break;
          
        case "html":
          const htmlContent = generateHTML(article);
          res.setHeader('Content-Type', 'text/html');
          res.setHeader('Content-Disposition', `attachment; filename="${article.title}.html"`);
          res.send(htmlContent);
          break;
          
        default:
          res.status(400).json({ message: "Invalid format. Use pdf, docx, or html" });
      }
    } catch (error) {
      console.error("Error downloading article:", error);
      res.status(500).json({ message: "Failed to download article" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
