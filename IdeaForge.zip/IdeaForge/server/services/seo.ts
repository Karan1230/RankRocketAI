export interface SEOAnalysis {
  score: number;
  wordCount: number;
  keywordDensity: number;
  readabilityScore: string;
  suggestions: string[];
  metaDescription: string;
  title: string;
}

export function analyzeSEO(content: string, title: string, keywords: string[]): SEOAnalysis {
  const wordCount = countWords(content);
  const keywordDensity = calculateKeywordDensity(content, keywords);
  const readabilityScore = calculateReadability(content);
  
  let score = 0;
  const suggestions: string[] = [];

  // Title length (50-60 characters is optimal)
  if (title.length >= 50 && title.length <= 60) {
    score += 15;
  } else {
    suggestions.push(`Title should be 50-60 characters (current: ${title.length})`);
  }

  // Keyword density (1.5-2% is optimal)
  if (keywordDensity >= 1.5 && keywordDensity <= 2.0) {
    score += 20;
  } else if (keywordDensity < 1.5) {
    suggestions.push("Increase keyword density to 1.5-2%");
  } else {
    suggestions.push("Reduce keyword density to avoid over-optimization");
  }

  // Word count
  if (wordCount >= 1000) {
    score += 20;
  } else {
    suggestions.push("Consider adding more content (1000+ words recommended)");
  }

  // Headings structure
  const hasH1 = content.includes('<h1');
  const hasH2 = content.includes('<h2');
  const hasH3 = content.includes('<h3');
  
  if (hasH1 && hasH2) {
    score += 15;
  } else {
    suggestions.push("Add proper heading structure (H1, H2, H3)");
  }

  // Content structure
  const paragraphs = content.split('</p>').length - 1;
  if (paragraphs >= 5) {
    score += 10;
  } else {
    suggestions.push("Break content into more paragraphs for better readability");
  }

  // Meta description
  const metaDescription = generateMetaDescription(content);
  if (metaDescription.length >= 120 && metaDescription.length <= 155) {
    score += 10;
  }

  // Readability bonus
  if (readabilityScore === "Excellent") {
    score += 10;
  } else if (readabilityScore === "Good") {
    score += 5;
  }

  return {
    score: Math.min(score, 100),
    wordCount,
    keywordDensity,
    readabilityScore,
    suggestions,
    metaDescription,
    title
  };
}

function countWords(text: string): number {
  // Remove HTML tags and count words
  const cleanText = text.replace(/<[^>]*>/g, ' ');
  const words = cleanText.trim().split(/\s+/);
  return words.filter(word => word.length > 0).length;
}

function calculateKeywordDensity(content: string, keywords: string[]): number {
  const cleanContent = content.replace(/<[^>]*>/g, ' ').toLowerCase();
  const totalWords = countWords(content);
  
  let keywordCount = 0;
  keywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword.toLowerCase()}\\b`, 'g');
    const matches = cleanContent.match(regex);
    keywordCount += matches ? matches.length : 0;
  });

  return totalWords > 0 ? (keywordCount / totalWords) * 100 : 0;
}

function calculateReadability(content: string): string {
  const cleanText = content.replace(/<[^>]*>/g, ' ');
  const sentences = cleanText.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = cleanText.trim().split(/\s+/).filter(w => w.length > 0);
  
  if (sentences.length === 0 || words.length === 0) return "Poor";
  
  const avgWordsPerSentence = words.length / sentences.length;
  
  // Simple readability assessment
  if (avgWordsPerSentence <= 15) {
    return "Excellent";
  } else if (avgWordsPerSentence <= 20) {
    return "Good";
  } else if (avgWordsPerSentence <= 25) {
    return "Fair";
  } else {
    return "Poor";
  }
}

function generateMetaDescription(content: string): string {
  const cleanText = content.replace(/<[^>]*>/g, ' ').trim();
  const firstSentence = cleanText.split(/[.!?]+/)[0];
  
  if (firstSentence.length <= 155) {
    return firstSentence.trim();
  }
  
  return firstSentence.substring(0, 152).trim() + "...";
}

export function generateInternalLinks(content: string, existingArticles: Array<{title: string, id: string}>): string {
  let linkedContent = content;
  
  existingArticles.forEach(article => {
    const keywords = article.title.split(' ').filter(word => word.length > 4);
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b(?![^<]*>)`, 'gi');
      linkedContent = linkedContent.replace(regex, (match) => {
        if (linkedContent.includes(`href="/articles/${article.id}"`)) {
          return match; // Already linked
        }
        return `<a href="/articles/${article.id}" class="text-blue-600 hover:text-blue-800 underline">${match}</a>`;
      });
    });
  });
  
  return linkedContent;
}
