import { GoogleGenAI, Modality } from "@google/genai";
import type { GenerateArticleRequest } from "@shared/schema";
import * as fs from "fs";
import * as path from "path";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || "" 
});

export interface GeneratedArticle {
  title: string;
  content: string;
  metaDescription: string;
  keywords: string[];
  wordCount: number;
  seoScore: number;
  readabilityScore: string;
}

export interface GeneratedImage {
  url: string;
  alt: string;
  prompt: string;
}

export async function generateArticleContent(request: GenerateArticleRequest): Promise<GeneratedArticle> {
  try {
    const { topic, language, wordCount, tone } = request;
    
    const systemPrompt = `You are an expert content writer and SEO specialist. Create a comprehensive, high-quality blog article that is:
- SEO-optimized with proper keyword density (1.5-2%)
- Written in ${language} language
- Approximately ${wordCount} words
- Using a ${tone} tone
- Includes proper H1, H2, H3 headings structure
- Contains engaging introduction and conclusion
- Includes relevant keywords naturally integrated
- AdSense policy compliant
- Plagiarism-free and original content

Topic: ${topic}

Return the response as JSON with this exact structure:
{
  "title": "SEO-optimized title",
  "content": "Full article content with HTML headings and paragraphs",
  "metaDescription": "155-character meta description",
  "keywords": ["keyword1", "keyword2", "keyword3"],
  "wordCount": actual_word_count,
  "seoScore": score_out_of_100,
  "readabilityScore": "Good/Fair/Excellent"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            metaDescription: { type: "string" },
            keywords: { 
              type: "array",
              items: { type: "string" }
            },
            wordCount: { type: "number" },
            seoScore: { type: "number" },
            readabilityScore: { type: "string" }
          },
          required: ["title", "content", "metaDescription", "keywords", "wordCount", "seoScore", "readabilityScore"]
        }
      },
      contents: `Generate an article about: ${topic}`
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini API");
    }

    const generatedArticle: GeneratedArticle = JSON.parse(rawJson);
    return generatedArticle;
  } catch (error) {
    console.error("Error generating article:", error);
    throw new Error(`Failed to generate article: ${error}`);
  }
}

export async function generateArticleImages(
  topic: string, 
  imageCount: number, 
  style: string
): Promise<GeneratedImage[]> {
  const images: GeneratedImage[] = [];
  
  try {
    for (let i = 0; i < imageCount; i++) {
      const imagePrompt = `Create a high-quality ${style} style image related to "${topic}". 
      Make it professional, engaging, and suitable for a blog article. 
      ${style === 'realistic' ? 'Photorealistic style.' : ''}
      ${style === 'digital-art' ? 'Digital art style with modern aesthetics.' : ''}
      ${style === 'cartoon' ? 'Cartoon illustration style.' : ''}
      ${style === 'anime' ? 'Anime/manga art style.' : ''}`;

      const imagePath = path.join('/tmp', `generated-image-${Date.now()}-${i}.png`);
      
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-preview-image-generation",
        contents: [{ role: "user", parts: [{ text: imagePrompt }] }],
        config: {
          responseModalities: [Modality.TEXT, Modality.IMAGE],
        },
      });

      const candidates = response.candidates;
      if (candidates && candidates.length > 0) {
        const content = candidates[0].content;
        if (content?.parts) {
          for (const part of content.parts) {
            if (part.inlineData?.data) {
              const imageData = Buffer.from(part.inlineData.data, "base64");
              fs.writeFileSync(imagePath, imageData);
              
              // In a real app, you'd upload this to cloud storage and return the URL
              // For now, we'll use a data URL
              const dataUrl = `data:image/png;base64,${part.inlineData.data}`;
              
              images.push({
                url: dataUrl,
                alt: `AI-generated image for ${topic}`,
                prompt: imagePrompt
              });
              break;
            }
          }
        }
      }
    }
    
    return images;
  } catch (error) {
    console.error("Error generating images:", error);
    // Return empty array if image generation fails
    return [];
  }
}

export async function filterNSFWContent(content: string): Promise<{ isClean: boolean; cleanedContent?: string }> {
  try {
    const systemPrompt = `You are a content safety filter. Analyze the following content for:
- Adult/sexual content
- Violence or harmful content  
- Hate speech or discrimination
- Illegal activities
- Content that violates AdSense policies

Return JSON with:
{
  "isClean": boolean,
  "cleanedContent": "cleaned version if needed, or original if clean",
  "issues": ["list of issues found"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            isClean: { type: "boolean" },
            cleanedContent: { type: "string" },
            issues: { 
              type: "array",
              items: { type: "string" }
            }
          },
          required: ["isClean", "cleanedContent", "issues"]
        }
      },
      contents: content
    });

    const result = JSON.parse(response.text || '{"isClean": false}');
    return result;
  } catch (error) {
    console.error("Error filtering content:", error);
    return { isClean: true, cleanedContent: content };
  }
}
