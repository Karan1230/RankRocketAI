import type { Article } from "@shared/schema";

export function generatePDF(article: Article): Buffer {
  // In a real implementation, you'd use a library like puppeteer or jsPDF
  // For now, return a simple text representation
  const content = `
Title: ${article.title}

Meta Description: ${article.metaDescription}

Content:
${article.content.replace(/<[^>]*>/g, '')}

Keywords: ${article.keywords?.join(', ')}
Word Count: ${article.wordCount}
SEO Score: ${article.seoScore}/100
Generated: ${article.createdAt}
`;
  
  return Buffer.from(content, 'utf-8');
}

export function generateDOCX(article: Article): Buffer {
  // In a real implementation, you'd use a library like docx
  // For now, return a simple text representation
  const content = `
Title: ${article.title}

Meta Description: ${article.metaDescription}

Content:
${article.content.replace(/<[^>]*>/g, '')}

Keywords: ${article.keywords?.join(', ')}
Word Count: ${article.wordCount}
SEO Score: ${article.seoScore}/100
Generated: ${article.createdAt}
`;
  
  return Buffer.from(content, 'utf-8');
}

export function generateHTML(article: Article): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${article.title}</title>
    <meta name="description" content="${article.metaDescription}">
    <meta name="keywords" content="${article.keywords?.join(', ')}">
    <style>
        body { 
            font-family: Arial, sans-serif; 
            line-height: 1.6; 
            max-width: 800px; 
            margin: 0 auto; 
            padding: 20px; 
        }
        h1, h2, h3 { color: #333; }
        .meta { 
            color: #666; 
            font-size: 0.9em; 
            margin-bottom: 20px; 
        }
        .seo-info {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <h1>${article.title}</h1>
    <div class="meta">
        <p><strong>Generated:</strong> ${new Date(article.createdAt || '').toLocaleDateString()}</p>
        <p><strong>Word Count:</strong> ${article.wordCount}</p>
        <p><strong>Language:</strong> ${article.language}</p>
        <p><strong>Tone:</strong> ${article.tone}</p>
    </div>
    
    ${article.content}
    
    <div class="seo-info">
        <h3>SEO Information</h3>
        <p><strong>Meta Description:</strong> ${article.metaDescription}</p>
        <p><strong>Keywords:</strong> ${article.keywords?.join(', ')}</p>
        <p><strong>SEO Score:</strong> ${article.seoScore}/100</p>
        <p><strong>Readability:</strong> ${article.readabilityScore}</p>
    </div>
</body>
</html>`;
}
